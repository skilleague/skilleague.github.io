# -*- coding: utf-8 -*-
"""
Created on Sat Jan 29 11:23:41 2022

@author: Basavaraj.J
"""

from azureml.core import Workspace, Run, Dataset, Datastore, Model
from sklearn.model_selection import train_test_split
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
import joblib
import numpy as np

new_run = Run.get_context()
ws = new_run.experiment.workspace



ds_store = Datastore.get(workspace=ws, datastore_name='dshouseprice')
ds_data = Dataset.get_by_name(workspace=ws, name="House Price Prediction Data")


data = ds_data.to_pandas_dataframe()


new_run.log("Total Observations", len(data))

new_data = data[data.price < data.price.mean() + (1.5* data.price.std())]
new_data = new_data[new_data['price'] > 100]

new_run.log("Observations in training data", len(new_data))
g = new_data.groupby('city').agg({'price':'mean'})
new_data = g.reset_index().merge(new_data, on='city', how='inner')
new_data['xcity'] = new_data['price_y']/new_data['price_x']

new_data['yr_built'] = new_data['yr_built'].astype('category').cat.codes
new_data['yr_renovated'] = new_data['yr_renovated'].astype('category').cat.codes


X = new_data[['bedrooms', 'bathrooms', 'sqft_living', 'sqft_lot',
       'floors', 'waterfront', 'view', 'condition', 'sqft_above',
       'sqft_basement', 'yr_built', 'yr_renovated', 'xcity']]

Y = new_data['price_y']

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size = 0.3, random_state = 1234)

lr = RandomForestRegressor()
lr.fit(X_train, Y_train)
Y_predict = lr.predict(X_test)

score = lr.score(X_test, Y_test)
rmse = np.sqrt(mean_squared_error(Y_test, Y_predict))

new_run.log("Score", score)
new_run.log("Root Mean Squared Error", rmse)


X_test = X_test.reset_index(drop=True)
Y_test = Y_test.reset_index(drop=True)

Y_predict_df = pd.DataFrame(Y_predict, columns=["Predicted prices"]) 

scored_dataset = pd.concat([X_test, Y_test, Y_predict_df], axis=1)

scored_dataset.to_csv("./outputs/predicted_house_prices.csv", index=False)
model_file = "./outputs/model.pkl"

joblib.dump(lr, filename=model_file)

'''
new_run.register_model(model_path='outputs/model.pkl', 
                       model_name='HousePricePrediction',
                       tags={'source':'SDK Run', 'algorithm':'RandomForestRegression'},
                       properties={'Score': score},
                       description="HousePricePrediction")
'''

new_run.complete()

Model.register(workspace=ws,
               model_path='./outputs/model.pkl',
               model_name='HousePricePrediction',
               tags={'source':'SDK-Local', 'algorithm':'RandomForestRegression'},
               properties={'Score': 0.711},
               description='HousePricePrediction'
               )

