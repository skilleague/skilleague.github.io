# -*- coding: utf-8 -*-
"""
Created on Tue Feb  1 21:27:20 2022

@author: Basavaraj.J
"""
import os
from azureml.core.model import InferenceConfig
from azureml.core import Workspace, Environment, Model
from azureml.core.webservice import AciWebservice
from azureml.core.compute import ComputeTarget
from azureml.core.authentication import ServicePrincipalAuthentication

print(os.listdir())

appid = "fd83d6e9-4c09-4768-8da7-229e75f8f554"
tenantid = "97984c2b-a229-4609-8185-ae84947bc3fc"
cert_value= "oPh7Q~EDIrDcbDf~MYlNlO3HbXNTHJGf3AWR2"  # password
#secret_id = a93b4f7a-da5d-4ffc-aeb2-54f3d1a6830d
#svc_pr_password = os.environ.get("AZUREML_PASSWORD")

compute_name = 'aml-cluster'

svc_pr = ServicePrincipalAuthentication(
    tenant_id=tenantid,
    service_principal_id=appid,
    service_principal_password=cert_value)

ws = Workspace.get(name="amlworkspace",
               subscription_id='188999a5-9be9-4c40-bfc4-340afe0afb07',
               resource_group='Brillio-DAE',
               auth=svc_pr)

myenv = Environment.get(workspace=ws, name="MyEnvironment")


inference_config = InferenceConfig(source_directory = './_Aml_CI_pipeline/Job1',
                                   entry_script="scoring.py",
                                   environment=myenv)

deploy_config = AciWebservice.deploy_configuration(cpu_cores=1, memory_gb=1)

aml_cluster = ComputeTarget(workspace=ws, name=compute_name)

model = ws.models['HousePricePrediction']
service = Model.deploy(workspace=ws, 
                       name='price-prediction', 
                       models=[model], 
                       inference_config=inference_config, 
                       deployment_config=deploy_config, 
                       deployment_target=aml_cluster)

service.wait_for_deployment(show_output=True)









