# -*- coding: utf-8 -*-
"""
Created on Sat Jan 29 11:10:20 2022

@author: Basavaraj.J
"""

#import os
from azureml.core import Workspace, Experiment, ScriptRunConfig
from azureml.core import Environment
from azureml.core.environment import CondaDependencies
from azureml.core.authentication import ServicePrincipalAuthentication
from azureml.core.compute import ComputeTarget, AmlCompute
from azureml.core.compute_target import ComputeTargetException

appid = "fd83d6e9-4c09-4768-8da7-229e75f8f554"
tenantid = "97984c2b-a229-4609-8185-ae84947bc3fc"

cert_value= "oPh7Q~EDIrDcbDf~MYlNlO3HbXNTHJGf3AWR2"  # password
#secret_id = a93b4f7a-da5d-4ffc-aeb2-54f3d1a6830d


#svc_pr_password = os.environ.get("AZUREML_PASSWORD")

compute_name = 'aml-cluster'

svc_pr = ServicePrincipalAuthentication(
    tenant_id=tenantid,
    service_principal_id=appid,
    service_principal_password=cert_value)

ws = Workspace.get(name="amlworkspace",
               subscription_id='188999a5-9be9-4c40-bfc4-340afe0afb07',
               resource_group='Brillio-DAE',
               auth=svc_pr)

new_experiment = Experiment(workspace=ws,
                            name="Training_Script")

myenv = Environment(name="MyEnvironment")

# Create the dependencies object
myenv_dep = CondaDependencies.create(conda_packages=['numpy', 'pandas', 'scikit-learn'])
myenv.python.conda_dependencies = myenv_dep

# Register the environment
myenv.register(ws)


try:
    aml_cluster = ComputeTarget(workspace=ws, name=compute_name)
except ComputeTargetException:
    compute_config = AmlCompute.provisioning_configuration(vm_size='STANDARD_DS11_V2', max_nodes=2)
    aml_cluster = ComputeTarget.create(ws, compute_name, compute_config)
    
aml_cluster.wait_for_completion(show_output=True)


script_config = ScriptRunConfig(source_directory="cicd",
                                script="training_script.py",
                                environment=myenv,
                                compute_target=compute_name)


# Submit a new run using the ScriptRunConfig
new_run = new_experiment.submit(config=script_config)


# Create a wait for completion of the script
new_run.wait_for_completion()




