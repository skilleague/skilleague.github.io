# -*- coding: utf-8 -*-
"""
Created on Tue Feb  1 21:15:58 2022

@author: Basavaraj.J
"""

import joblib
import json
import pandas as pd
from azureml.core.model import Model

def init():
    global predictor
    model_path = Model.get_model_path('HousePricePrediction')
    predictor = joblib.load(model_path)
    

def run(raw_data):
    data_dict = json.loads(raw_data)['data']
    data = pd.DataFrame.from_dict(data_dict)
    
    data_enc = pd.get_dummies(data)
    #deploy_cols = data_enc.columns
    
    predictions = predictor.predict(data_enc)
    
    return json.dumps(predictions)
    